public class UcakOlusturma {
     public static Ucak[] getUCak() {
        return new Ucak[] {
            new Ucak("ATR 42", 50, 599, "Aktif"),
            new Ucak("DOUGLAS MD-90", 150, 9, "Aktif"),
            new Ucak("TUPOLEV TU-334", 100, 334, "Aktif"),
            new Ucak("FOKKER 100", 100, 100, "Aktif"),

        };
    }
}
