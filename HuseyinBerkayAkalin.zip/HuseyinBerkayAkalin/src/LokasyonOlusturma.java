public class LokasyonOlusturma {
    public static Lokasyon[] getLokasyon() {
        return new Lokasyon[] {
            new Lokasyon("Türkiye", "İstanbul", "Sabiha Gökçen Havalimanı"),
            new Lokasyon("Türkiye", "Ankara", "Esenboğa Havalimanı"),
            new Lokasyon("Türkiye", "İzmir", "Adnan Menderes Havalimanı"),
            new Lokasyon("Türkiye", "Antalya", "Antalya Havalimanı"),
            new Lokasyon("İtalya", "Bari", "Bari KArol Wojtyla Havalimanı"),
            new Lokasyon("İtalya", "Pisa", "Pisa Uluslarası Havalimanı"),
            new Lokasyon("Almanya", "Berlin", "Berlin Schönefeld Havalimanı"),
            new Lokasyon("İtalya", "Roma", "Fiumicino Havalimanı"),
            new Lokasyon("Yunanistan", "Atina", "Elefterios Venizelos Havaalanı"),
            new Lokasyon("Hollanda", "Amsterdam", "Schipol Havalimanı")
        };
    }
}
